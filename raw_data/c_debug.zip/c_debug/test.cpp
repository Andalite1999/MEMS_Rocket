#include <iostream>

float cedric = 0.0f;

int main() {
    std::cout << "Hello, World!" << cedric << "\n";
    cedric += 1.1f;
    std::cout << cedric << "\n";
    return 0;
}
